Run ./envoy-proto-gen.sh to generate xds proto generated code for grpc usage.
Make sure your $GOPATH is valid and you have grpc-go repo locally.