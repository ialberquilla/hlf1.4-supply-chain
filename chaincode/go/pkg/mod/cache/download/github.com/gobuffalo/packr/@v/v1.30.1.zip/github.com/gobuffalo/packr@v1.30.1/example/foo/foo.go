package foo

import "github.com/gobuffalo/packr"

func init() {
	packr.NewBox("../templates")
}
