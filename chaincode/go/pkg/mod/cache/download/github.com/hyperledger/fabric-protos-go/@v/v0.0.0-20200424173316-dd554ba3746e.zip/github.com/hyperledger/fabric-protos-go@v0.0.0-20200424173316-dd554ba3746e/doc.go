// Copyright the Hyperledger Fabric contributors. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

// Package protos contains the protobuf and gRPC service bindings for
// Hyperledger Fabric.
package protos
